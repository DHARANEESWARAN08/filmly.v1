import { createContext, PropsWithChildren, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { supabase } from '../services/supabase';
import { authService } from '../services/authService';
import { favoriteService } from '../services/favoriteService';
import { watchlistService } from '../services/watchlistService';
import { reviewService } from '../services/reviewService';
import { FilmlyUser } from '../types/auth';
import { MovieCollection, MovieSummary, Review, WatchStatus } from '../types/movie';

export type UserData = {
  favorites: MovieCollection;
  want: MovieCollection;
  watching: MovieCollection;
  watched: MovieCollection;
  reviews: Review[];
};

type AppContextValue = {
  booting: boolean;
  user: FilmlyUser | null;
  data: UserData;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, username: string) => Promise<void>;
  signOut: () => Promise<void>;
  toggleFavorite: (movie: MovieSummary) => Promise<void>;
  setStatus: (movie: MovieSummary, status: WatchStatus) => Promise<void>;
  addReview: (review: Review) => Promise<void>;
  isFavorite: (movieId: number) => boolean;
  getStatus: (movieId: number) => WatchStatus | null;
};

const AppContext = createContext<AppContextValue | null>(null);

function freshUserData(): UserData {
  return {
    favorites: {},
    want: {},
    watching: {},
    watched: {},
    reviews: [],
  };
}

export function AppProvider({ children }: PropsWithChildren) {
  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState<FilmlyUser | null>(null);
  const [data, setData] = useState<UserData>(freshUserData);

  // Subscribe to auth state changes
  useEffect(() => {
    let mounted = true;

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        console.log(`[AUTH] Session restored for user ID: ${session.user.id}`);
        try {
          const currentUser = await authService.getCurrentUser();
          if (mounted) {
            setUser(currentUser);
            if (currentUser) {
              // Hydrate user data from Supabase
              const [favs, watch, revs] = await Promise.all([
                favoriteService.fetchFavorites(currentUser.id),
                watchlistService.fetchWatchlist(currentUser.id),
                reviewService.fetchUserReviews(currentUser.id),
              ]);
              if (mounted) {
                setData({
                  favorites: favs,
                  want: watch.want,
                  watching: watch.watching,
                  watched: watch.watched,
                  reviews: revs,
                });
              }
            }
          }
        } catch (e) {
          console.error('Failed to load user session data:', e);
        } finally {
          if (mounted) {
            setBooting(false);
          }
        }
      } else {
        if (mounted) {
          setUser(null);
          setData(freshUserData());
          setBooting(false);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    setBooting(true);
    try {
      const filmlyUser = await authService.signIn(email, password);
      setUser(filmlyUser);
    } finally {
      setBooting(false);
    }
  }, []);

  const signUp = useCallback(async (email: string, password: string, username: string) => {
    setBooting(true);
    try {
      const result = await authService.signUp(email, password, username);
      setUser(result.user);
    } finally {
      setBooting(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    setBooting(true);
    try {
      await authService.signOut();
      setUser(null);
      setData(freshUserData());
    } finally {
      setBooting(false);
    }
  }, []);

  const toggleFavorite = useCallback(
    async (movie: MovieSummary) => {
      if (!user) return;
      const nextFavs = { ...data.favorites };
      const isFav = Boolean(nextFavs[movie.id]);

      // Optimistic update
      if (isFav) {
        delete nextFavs[movie.id];
      } else {
        nextFavs[movie.id] = movie;
      }
      setData((prev) => ({ ...prev, favorites: nextFavs }));

      try {
        if (isFav) {
          await favoriteService.removeFavorite(user.id, movie.id);
        } else {
          await favoriteService.addFavorite(user.id, movie.id);
        }
      } catch (err) {
        console.error('Failed to toggle favorite in database:', err);
        // Rollback
        const originalFavs = await favoriteService.fetchFavorites(user.id);
        setData((prev) => ({ ...prev, favorites: originalFavs }));
      }
    },
    [data.favorites, user],
  );

  const setStatus = useCallback(
    async (movie: MovieSummary, status: WatchStatus) => {
      if (!user) return;

      // Optimistic update
      const next = {
        ...data,
        want: { ...data.want },
        watching: { ...data.watching },
        watched: { ...data.watched },
      };

      delete next.want[movie.id];
      delete next.watching[movie.id];
      delete next.watched[movie.id];

      next[status][movie.id] = movie;
      setData(next);

      try {
        await watchlistService.setWatchlistStatus(user.id, movie.id, status);
      } catch (err) {
        console.error('Failed to set watchlist status in database:', err);
        // Rollback
        const watch = await watchlistService.fetchWatchlist(user.id);
        setData((prev) => ({
          ...prev,
          want: watch.want,
          watching: watch.watching,
          watched: watch.watched,
        }));
      }
    },
    [data, user],
  );

  const addReview = useCallback(
    async (review: Review) => {
      if (!user) return;

      const enrichedReview: Review = {
        ...review,
        userName: user.name || 'Filmly Member',
        userEmail: user.email || 'member@filmly.local',
        userAvatar: user.avatar || undefined,
      };

      // Optimistic update
      const nextReviews = [
        enrichedReview,
        ...(data.reviews || []).filter((item) => item.movieId !== review.movieId),
      ];
      const nextWatched = {
        ...(data.watched || {}),
        [review.movieId]: {
          id: review.movieId,
          title: review.movieTitle,
          posterPath: review.posterPath,
          backdropPath: null,
          rating: review.rating,
          releaseDate: '',
          overview: review.text,
          genres: [],
        },
      };

      setData((prev) => ({
        ...prev,
        reviews: nextReviews,
        watched: nextWatched,
      }));

      try {
        await Promise.all([
          reviewService.saveReview(user.id, review.movieId, review.rating, review.text),
          watchlistService.setWatchlistStatus(user.id, review.movieId, 'watched'),
        ]);
      } catch (err) {
        console.error('Failed to save review in database:', err);
        // Rollback
        const [revs, watch] = await Promise.all([
          reviewService.fetchUserReviews(user.id),
          watchlistService.fetchWatchlist(user.id),
        ]);
        setData((prev) => ({
          ...prev,
          reviews: revs,
          want: watch.want,
          watching: watch.watching,
          watched: watch.watched,
        }));
      }
    },
    [data.reviews, data.watched, user],
  );

  const isFavorite = useCallback((movieId: number) => Boolean(data?.favorites?.[movieId]), [data?.favorites]);

  const getStatus = useCallback(
    (movieId: number): WatchStatus | null => {
      if (!data) return null;
      if (data.want?.[movieId]) return 'want';
      if (data.watching?.[movieId]) return 'watching';
      if (data.watched?.[movieId]) return 'watched';
      return null;
    },
    [data],
  );

  const value = useMemo(
    () => ({
      booting,
      user,
      data,
      signIn,
      signUp,
      signOut,
      toggleFavorite,
      setStatus,
      addReview,
      isFavorite,
      getStatus,
    }),
    [booting, user, data, signIn, signUp, signOut, toggleFavorite, setStatus, addReview, isFavorite, getStatus],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return context;
}
