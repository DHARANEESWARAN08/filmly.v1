import { useApp } from '../context/AppContext';

export function useAuth() {
  const { user, booting, signIn, signUp, signOut } = useApp();
  return { user, booting, signIn, signUp, signOut };
}
