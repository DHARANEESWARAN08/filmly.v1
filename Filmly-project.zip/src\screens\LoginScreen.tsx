import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { useAuth } from '../hooks/useAuth';
import { colors, spacing } from '../theme/colors';

export function LoginScreen() {
  const { signIn, signUp } = useAuth();
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const isValidEmail = email.trim().includes('@');
  const canSubmit = isSignUp
    ? isValidEmail && username.trim().length > 1 && password.length >= 6
    : isValidEmail && password.length >= 6;

  const handleSubmit = async () => {
    if (!canSubmit || loading) return;
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        await signUp(email, password, username);
      } else {
        await signIn(email, password);
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={{
          uri: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1000&q=80',
        }}
        style={StyleSheet.absoluteFill}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(8,10,15,0.18)', 'rgba(8,10,15,0.82)', colors.background]}
          style={StyleSheet.absoluteFill}
        />
      </ImageBackground>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 22}
        style={styles.keyboard}
      >
        <ScrollView
          contentContainerStyle={styles.inner}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.brandBlock}>
            <Image source={require('../../assets/filmly-logo.png')} style={styles.logo} resizeMode="contain" />
          </View>

          <View style={styles.panel}>
            <View style={styles.previewRow}>
              <Image source={require('../../assets/filmly-mark.png')} style={styles.loginMark} resizeMode="contain" />
              <View style={styles.previewCopy}>
                <Text style={styles.panelTitle}>{isSignUp ? 'Join Filmly' : 'Welcome back'}</Text>
                <Text style={styles.panelSub}>
                  {isSignUp
                    ? 'Create an account to start syncing your cinema library.'
                    : 'Sign in to access your reviews, favorites, and watchlist.'}
                </Text>
              </View>
            </View>

            {loading ? (
              <ActivityIndicator size="large" color={colors.accent} style={styles.loader} />
            ) : (
              <>
                <View style={styles.accountForm}>
                  <Text style={styles.inputLabel}>Email Address</Text>
                  <TextInput
                    value={email}
                    onChangeText={setEmail}
                    placeholder="you@domain.com"
                    placeholderTextColor={colors.faint}
                    style={styles.input}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    autoCorrect={false}
                  />

                  {isSignUp && (
                    <>
                      <Text style={styles.inputLabel}>Username</Text>
                      <TextInput
                        value={username}
                        onChangeText={setUsername}
                        placeholder="cinema_fan"
                        placeholderTextColor={colors.faint}
                        style={styles.input}
                        autoCapitalize="none"
                        autoCorrect={false}
                      />
                    </>
                  )}

                  <Text style={styles.inputLabel}>Password</Text>
                  <TextInput
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                    autoCorrect={false}
                    placeholder="At least 6 characters"
                    placeholderTextColor={colors.faint}
                    style={styles.input}
                  />

                  <Pressable
                    onPress={handleSubmit}
                    disabled={!canSubmit}
                    style={[styles.accountButton, !canSubmit && styles.disabledButton]}
                  >
                    <Ionicons
                      name={isSignUp ? 'person-add-outline' : 'log-in-outline'}
                      size={18}
                      color={colors.background}
                    />
                    <Text style={styles.accountButtonText}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>
                  </Pressable>
                </View>

                {error ? <Text style={styles.error}>{error}</Text> : null}

                <Pressable onPress={() => setIsSignUp(!isSignUp)} style={styles.toggleButton}>
                  <Text style={styles.toggleText}>
                    {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
                  </Text>
                </Pressable>
              </>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background,
    flex: 1,
  },
  keyboard: {
    flex: 1,
  },
  inner: {
    flexGrow: 1,
    justifyContent: 'space-between',
    padding: spacing.page,
    paddingBottom: 34,
    paddingTop: 34,
  },
  brandBlock: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    height: 180,
    width: 180,
  },
  panel: {
    backgroundColor: 'rgba(16,19,26,0.94)',
    borderColor: colors.line,
    borderRadius: 8,
    borderWidth: 1,
    padding: 16,
  },
  previewRow: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  loginMark: {
    height: 48,
    width: 48,
  },
  previewCopy: {
    flex: 1,
  },
  panelTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '900',
  },
  panelSub: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: '700',
    lineHeight: 17,
    marginTop: 3,
  },
  accountForm: {
    marginTop: 4,
  },
  inputLabel: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: '900',
    marginBottom: 7,
    marginTop: 12,
    textTransform: 'uppercase',
  },
  input: {
    backgroundColor: colors.background,
    borderColor: colors.line,
    borderRadius: 8,
    borderWidth: 1,
    color: colors.text,
    fontSize: 14,
    minHeight: 48,
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  accountButton: {
    alignItems: 'center',
    backgroundColor: colors.accent,
    borderRadius: 8,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 16,
    minHeight: 48,
  },
  disabledButton: {
    opacity: 0.45,
  },
  accountButtonText: {
    color: colors.background,
    fontSize: 14,
    fontWeight: '900',
  },
  error: {
    color: colors.hot,
    fontSize: 12,
    fontWeight: '700',
    lineHeight: 17,
    marginTop: 12,
    textAlign: 'center',
  },
  loader: {
    marginVertical: 28,
  },
  toggleButton: {
    marginTop: 16,
    alignItems: 'center',
    paddingVertical: 8,
  },
  toggleText: {
    color: colors.accent,
    fontSize: 13,
    fontWeight: '700',
  },
});
