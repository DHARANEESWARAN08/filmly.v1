import { supabase } from './supabase';
import { FilmlyUser } from '../types/auth';

function getAvatarUrl(username: string) {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=FF1744&color=FFFFFF&size=150&bold=true`;
}

function formatAuthError(error: any, operation: 'signup' | 'login'): Error {
  if (!error) return new Error('Unknown authentication error');
  const msg = error.message || '';
  const status = error.status;

  if (operation === 'signup') {
    if (msg.toLowerCase().includes('rate limit') || status === 429) {
      return new Error('Signup failed: Email rate limit exceeded. Please wait a moment before trying again.');
    }
    if (msg.toLowerCase().includes('already registered') || msg.toLowerCase().includes('already exists')) {
      return new Error('Signup failed: Email already exists');
    }
    return new Error(`Signup failed: ${msg}`);
  } else {
    if (msg.toLowerCase().includes('invalid grant') || msg.toLowerCase().includes('invalid credentials')) {
      return new Error('Login failed: Invalid email or password');
    }
    return new Error(`Login failed: ${msg}`);
  }
}

export const authService = {
  async signUp(email: string, password: string, username: string): Promise<{ user: FilmlyUser; session: any }> {
    const cleanEmail = email.trim();
    const cleanUsername = username.trim().toLowerCase().replace(/\s+/g, '.');

    console.log(`[AUTH] Attempting signup for email: ${cleanEmail}`);

    if (cleanUsername.length < 2 || password.length < 6) {
      const errorMsg = 'Enter a username and a password with at least 6 characters.';
      console.error(`[AUTH] Signup failed: ${errorMsg}`);
      throw new Error(errorMsg);
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
        options: {
          data: {
            username: cleanUsername,
          },
        },
      });

      if (error) {
        throw formatAuthError(error, 'signup');
      }

      const authUser = data.user;
      if (!authUser) {
        const errorMsg = 'Sign up completed but no user returned.';
        throw new Error(errorMsg);
      }

      console.log(`[AUTH] Signup success: User created with ID: ${authUser.id}`);

      return {
        user: {
          id: authUser.id,
          email: cleanEmail,
          username: cleanUsername,
          name: cleanUsername,
          avatar: getAvatarUrl(cleanUsername),
        },
        session: data.session,
      };
    } catch (err: any) {
      console.error(`[AUTH] Signup failed: ${err.message}`);
      throw err;
    }
  },

  async signIn(email: string, password: string): Promise<FilmlyUser> {
    const cleanEmail = email.trim();
    console.log(`[AUTH] Attempting login for email: ${cleanEmail}`);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password,
      });

      if (error) {
        throw formatAuthError(error, 'login');
      }

      const authUser = data.user;
      if (!authUser) {
        const errorMsg = 'Sign in succeeded but user is missing.';
        throw new Error(errorMsg);
      }

      // Fetch user profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .single();

      const username = profile?.username || authUser.email?.split('@')[0] || 'Filmly Member';

      console.log(`[AUTH] Login success: Logged in with ID: ${authUser.id}`);

      return {
        id: authUser.id,
        email: authUser.email || cleanEmail,
        username,
        name: username,
        avatar: getAvatarUrl(username),
      };
    } catch (err: any) {
      console.error(`[AUTH] Login failed: ${err.message}`);
      throw err;
    }
  },

  async signOut(): Promise<void> {
    console.log('[AUTH] Attempting logout...');
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error(`[AUTH] Logout failed: ${error.message}`);
      throw new Error(error.message);
    }
    console.log('[AUTH] Logout successful');
  },

  async getCurrentUser(): Promise<FilmlyUser | null> {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !session?.user) {
      return null;
    }

    const authUser = session.user;

    // Fetch user profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authUser.id)
      .single();

    const username = profile?.username || authUser.email?.split('@')[0] || 'Filmly Member';

    return {
      id: authUser.id,
      email: authUser.email || '',
      username,
      name: username,
      avatar: getAvatarUrl(username),
    };
  },
};
